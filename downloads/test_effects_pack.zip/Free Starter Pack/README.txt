Free Starter Pack 1.0.0 for 3D-TVision
Three free effects that come with 3D-TVision, to learn adding effects with.

3 effect(s). Released: 2026-09-26. Needs any 3D-TVision version with add-on effects.

To install: in 3D-TVision open the MODE list, press the folder button under
the white line, pick this .zip (no need to unpack it), then All and Add.
Installing a newer version of a pack replaces the effects you already have.
